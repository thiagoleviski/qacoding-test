// Custom Cypress commands for Google Search tests
// Add reusable commands here if needed
