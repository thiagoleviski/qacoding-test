export const elements = {
  searchInput: 'textarea[name="q"]',
  searchResultsContainer: 'div[id="rso"]',
  searchResultItems: 'div[id="rso"] > div',
  searchResultLinks: 'div[id="rso"] h3 a'
};
